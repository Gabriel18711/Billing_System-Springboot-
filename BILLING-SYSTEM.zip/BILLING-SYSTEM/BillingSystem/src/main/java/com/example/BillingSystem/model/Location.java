package com.example.BillingSystem.model;

import jakarta.persistence.*;

@Entity
public class Location {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String description;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "latitude", column = @Column(name = "nurse_latitude")),
            @AttributeOverride(name = "longitude", column = @Column(name = "nurse_longitude"))
    })
    private Point nursePoint;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "latitude", column = @Column(name = "client_latitude")),
            @AttributeOverride(name = "longitude", column = @Column(name = "client_longitude"))
    })
    private Point clientPoint;

    @Transient
    private double distance;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Point getNursePoint() {
        return nursePoint;
    }

    public void setNursePoint(Point nursePoint) {
        this.nursePoint = nursePoint;
    }

    public Point getClientPoint() {
        return clientPoint;
    }

    public void setClientPoint(Point clientPoint) {
        this.clientPoint = clientPoint;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }
}
