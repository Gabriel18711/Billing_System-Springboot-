package com.example.BillingSystem.service;

import com.example.BillingSystem.model.Point;
import com.example.BillingSystem.model.Location;
import com.example.BillingSystem.model.Request;
import com.example.BillingSystem.repository.RequestRepository; // Import the repository
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
public class RequestService {

    @Autowired
    private RequestRepository requestRepository; // Inject the repository

    // Calculate price based on time
    public double calculatePriceBasedOnTime(Request request) {
        LocalDateTime requestTime = request.getTime();
        LocalDateTime now = LocalDateTime.now();
        long hoursBetween = ChronoUnit.HOURS.between(now, requestTime);

        // Let's assume that the price increases by $10 for each hour closer to the current time
        double basePrice = 50.0; // Base price
        return basePrice + (10.0 * Math.max(0, (24 - hoursBetween)));
    }

    // Calculate price based on distance
    public double calculatePriceBasedOnDistance(Request request) {
        Point nursePoint = request.getNursePoint();
        Point clientPoint = request.getClientPoint();

        double distance = calculateDistance(nursePoint, clientPoint);

        // For every kilometer, we charge K5 extra
        double basePrice = 2.0;
        return basePrice + (2.0 * distance);
    }

    // Calculate price based on rating and service type
    public double calculatePriceBasedOnRatingAndServiceType(Request request) {
        double ratingFactor = 1 + (request.getRating() / 10); // Higher rating increases price
        double basePrice = request.getServiceType().getPricePerUnit();
        return basePrice * ratingFactor;
    }

    // Utility method to calculate the distance between two points
    public double calculateDistance(Point nursePoint, Point clientPoint) {
        final int EARTH_RADIUS = 6371; // Radius of the Earth in km

        double latDistance = Math.toRadians(clientPoint.getLatitude() - nursePoint.getLatitude());
        double lonDistance = Math.toRadians(clientPoint.getLongitude() - nursePoint.getLongitude());

        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(nursePoint.getLatitude())) * Math.cos(Math.toRadians(clientPoint.getLatitude()))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return EARTH_RADIUS * c; // Distance in km
    }

    // New method to create a request and calculate price
    public Request createRequest(Request request) {
        double priceBasedOnTime = calculatePriceBasedOnTime(request);
        double priceBasedOnDistance = calculatePriceBasedOnDistance(request);
        double priceBasedOnRating = calculatePriceBasedOnRatingAndServiceType(request);

        // Calculate the final price (you can adjust how you calculate this)
        double finalPrice = (priceBasedOnTime + priceBasedOnDistance + priceBasedOnRating) / 3;

        // Set the final price in your Request object (assuming you have a setPrice method)
        request.setPrice(finalPrice);

        // Save the request to the database
        return requestRepository.save(request);
    }

    // Get all requests
    public List<Request> findAll() {
        return requestRepository.findAll(); // Get all requests from the repository
    }

    // Find request by ID
    public Request findById(Long id) {
        Optional<Request> requestOptional = requestRepository.findById(id);
        return requestOptional.orElseThrow(() -> new RuntimeException("Request not found")); // Handle not found
    }

    // Update request
    public Request updateRequest(Long id, Request updatedRequest) {
        Request existingRequest = findById(id);
        // Update fields of existingRequest with values from updatedRequest
        existingRequest.setClientPhoneNumber(updatedRequest.getClientPhoneNumber());
        existingRequest.setNursePhoneNumber(updatedRequest.getNursePhoneNumber());
        existingRequest.setServiceType(updatedRequest.getServiceType());
        existingRequest.setTime(updatedRequest.getTime());
        existingRequest.setNursePoint(updatedRequest.getNursePoint());
        existingRequest.setClientPoint(updatedRequest.getClientPoint());
        existingRequest.setRating(updatedRequest.getRating());

        // Recalculate price
        existingRequest.setPrice(calculatePrice(existingRequest));

        return requestRepository.save(existingRequest); // Save updated request
    }

    // Delete request
    public void deleteRequest(Long id) {
        requestRepository.deleteById(id); // Delete request from repository
    }

    // Utility method to calculate the total price based on all criteria
    private double calculatePrice(Request request) {
        double priceBasedOnTime = calculatePriceBasedOnTime(request);
        double priceBasedOnDistance = calculatePriceBasedOnDistance(request);
        double priceBasedOnRating = calculatePriceBasedOnRatingAndServiceType(request);
        return (priceBasedOnTime + priceBasedOnDistance + priceBasedOnRating) / 3; // Average price
    }
}
