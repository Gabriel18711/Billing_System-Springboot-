package com.example.BillingSystem.repository;

import com.example.BillingSystem.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByClientPhoneNumber(String clientPhoneNumber);
    List<Transaction> findByTransactionStatus(String status);
}
