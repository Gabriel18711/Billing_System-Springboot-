package com.example.BillingSystem.controller;

import com.example.BillingSystem.model.Location;
import com.example.BillingSystem.model.Point;
import com.example.BillingSystem.repository.LocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/locations")
public class LocationController {

    @Autowired
    private LocationRepository locationRepository;

    @PostMapping
    public ResponseEntity<Location> createLocation(@RequestBody Location location) {
        // Calculate the distance between nurse and client
        double distance = calculateDistance(location.getNursePoint(), location.getClientPoint());
        location.setDistance(distance);

        Location savedLocation = locationRepository.save(location);
        return new ResponseEntity<>(savedLocation, HttpStatus.CREATED);
    }

    private double calculateDistance(Point nursePoint, Point clientPoint) {
        final int EARTH_RADIUS = 6371; // Radius of the Earth in km

        double latDistance = Math.toRadians(clientPoint.getLatitude() - nursePoint.getLatitude());
        double lonDistance = Math.toRadians(clientPoint.getLongitude() - nursePoint.getLongitude());

        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(nursePoint.getLatitude())) * Math.cos(Math.toRadians(clientPoint.getLatitude()))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return EARTH_RADIUS * c; // Distance in km
    }
}
