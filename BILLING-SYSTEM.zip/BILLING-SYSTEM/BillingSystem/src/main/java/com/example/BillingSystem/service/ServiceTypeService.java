package com.example.BillingSystem.service;

import com.example.BillingSystem.model.ServiceType;
import com.example.BillingSystem.repository.ServiceTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class ServiceTypeService {

    @Autowired
    ServiceTypeRepository serviceTypeRepository;

    // Method to calculate price based on service type and other parameters
    public double calculatePrice(String serviceType, String nurseCompetence, double distance, String serviceTime) {
        double basePrice = 50; // Basic price
        double distanceFactor = distance * 10; // Price per kilometer
        double competenceFactor = Integer.parseInt(nurseCompetence) * 5; // Price based on competence level
        double timeFactor = serviceTime.contains("AM") ? 10 : 20; // Time factor (morning/evening pricing)

        return basePrice + distanceFactor + competenceFactor + timeFactor;
    }

    // Method to process the service type file
    public void processServiceTypeFile(MultipartFile file) {
        // Logic to read the file and store service types in the database
    }

    public ServiceType getById(Long id) {
        return  serviceTypeRepository.getById(id);
    }
}
