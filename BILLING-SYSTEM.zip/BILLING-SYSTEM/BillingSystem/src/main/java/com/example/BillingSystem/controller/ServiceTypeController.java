package com.example.BillingSystem.controller;

import com.example.BillingSystem.DTO.AmmountClass;
import com.example.BillingSystem.DTO.AmoutCheckerUsingDistanceServiceCompetenceLevel;
import com.example.BillingSystem.model.ServiceType;
import com.example.BillingSystem.repository.ServiceTypeRepository;
import com.example.BillingSystem.service.PriceCalculationService;
import com.example.BillingSystem.service.ServiceTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/service-types")
public class ServiceTypeController {

    @Autowired
    private ServiceTypeRepository serviceTypeRepository;

    @Autowired
    private ServiceTypeService serviceTypeService;

    @Autowired
    private PriceCalculationService priceCalculationService;


    @GetMapping("/getPrice")
    public ResponseEntity<AmmountClass> getTotalPrice(@RequestBody AmoutCheckerUsingDistanceServiceCompetenceLevel check){

        double overallPrice = priceCalculationService.overallPrice(check);
        AmmountClass amount = new AmmountClass(overallPrice);

        return ResponseEntity.ok(amount);

    }



    @PostMapping
    public ResponseEntity<ServiceType> createServiceType(@RequestBody ServiceType serviceType) {
        ServiceType savedServiceType = serviceTypeRepository.save(serviceType);
        return ResponseEntity.ok(savedServiceType);
    }

    @GetMapping
    public List<ServiceType> getAllServiceTypes() {
        return serviceTypeRepository.findAll();
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<ServiceType> getserviceByid(@PathVariable(value = "id") Long id) {
        ServiceType serviceType = serviceTypeService.getById(id);
        if (serviceType == null) {
            return ResponseEntity.notFound().build();
        }

        // Optionally, convert to DTO if you want to avoid serialization issues
        ServiceType dto = new ServiceType(serviceType.getId(), serviceType.getName(),serviceType.getPricePerUnit());
        return ResponseEntity.ok(dto);
    }

}
