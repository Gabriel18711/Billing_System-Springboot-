package com.example.BillingSystem.controller;

import com.example.BillingSystem.service.PaymentService;
import com.example.BillingSystem.model.PaymentRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    private final PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    // Endpoint to initiate payment
    @PostMapping("/initiatePayment")
    public ResponseEntity<String> initiatePayment(@RequestBody PaymentRequest paymentRequest) {
        // Call the service to initiate the payment
        String result = paymentService.initiatePayment(
                paymentRequest.getClientPhoneNumber(),
                paymentRequest.getNursePhoneNumber(),
                paymentRequest.getAmount()
        );
        // Return the result
        return ResponseEntity.ok(result);
    }

    // Endpoint to check the status of a payment transaction
    @GetMapping("/transactionStatus/{transactionId}")
    public ResponseEntity<String> checkTransactionStatus(@PathVariable String transactionId) {
        // Call the service to check the status of the transaction
        String status = paymentService.checkTransactionStatus(transactionId);
        // Return the status
        return ResponseEntity.ok(status);
    }
}
