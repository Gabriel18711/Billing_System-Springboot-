package com.example.BillingSystem.service;

import com.example.BillingSystem.DTO.AmoutCheckerUsingDistanceServiceCompetenceLevel;
import com.example.BillingSystem.model.Point;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PriceCalculationService {

    @Autowired
    private LocationService locationService;

    @Autowired
    private ServiceTypeService serviceTypeService;

//    private double calculatePrice(double distance, long competenceLevel,long serviceId){
//        double servicePrice = serviceTypeService.getById(serviceId).getPricePerUnit();
//
//        return 0;
//
//    }

    private double getDistance(AmoutCheckerUsingDistanceServiceCompetenceLevel check){
        return locationService.calculateDistance(check.getClientlat(),check.getClientlong(),check.getNurselat(),check.getNurselong());
    }

    public double overallPrice(AmoutCheckerUsingDistanceServiceCompetenceLevel check) {
        double distance = getDistance(check) * check.getCompetenceLevel();
        double servicePrice = serviceTypeService.getById(check.getServiceType()).getPricePerUnit();


        return distance + servicePrice;


    }


}
