package com.example.BillingSystem.controller;

import com.example.BillingSystem.model.Point;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/points")
public class PointController {

    // For demonstration purposes, using an in-memory list
    private List<Point> points = new ArrayList<>();

    @PostMapping
    public Point createPoint(@RequestBody Point point) {
        points.add(point);
        return point;  // Return the created point
    }

    @GetMapping
    public List<Point> getAllPoints() {
        return points;  // Return all points
    }
}
