package com.example.BillingSystem.repository;

import com.example.BillingSystem.model.Request;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RequestRepository extends JpaRepository<Request, Long> {
}
