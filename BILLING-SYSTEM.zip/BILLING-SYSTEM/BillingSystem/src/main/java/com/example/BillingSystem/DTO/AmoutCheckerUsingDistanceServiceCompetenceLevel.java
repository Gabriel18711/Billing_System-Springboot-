package com.example.BillingSystem.DTO;

import com.example.BillingSystem.model.Point;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AmoutCheckerUsingDistanceServiceCompetenceLevel {
    private Long serviceType;
    private int competenceLevel;

    private double nurselat;
    private double nurselong;

    private double clientlat;
    private double clientlong;

}
