package com.example.BillingSystem.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String clientPhoneNumber;
    private String nursePhoneNumber;
    private String amount;
    private String transactionStatus;
    private String transactionId;
    private LocalDateTime timestamp;

    public void setClientPhoneNumber(String clientPhoneNumber) {
    }

    public void setNursePhoneNumber(String nursePhoneNumber) {
    }

    public void setTransactionStatus(String statusText) {
    }

    public void setAmount(String amount) {
    }

    public void setTransactionId(String body) {
    }

    public void setTimestamp(LocalDateTime now) {

    }

    // Getters and Setters
}
