// PaymentService.java
package com.example.BillingSystem.service;

import com.example.BillingSystem.model.Transaction;
import com.example.BillingSystem.repository.TransactionRepository;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service

public class PaymentService {

    private final TransactionRepository transactionRepository;

    @Autowired
    public PaymentService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    public String initiatePayment(String clientPhoneNumber, String nursePhoneNumber, String amount) {
        // Process the payment with the payment API (as before)
        HttpResponse<String> response = Unirest.post("https://api.moneyunify.com/v2/request_payment")
                .header("User-Agent", "Apidog/1.0.0")
                .field("muid", "01JB9D8CPZEC8JWEPBDP510HGH")
                .field("phone_number", clientPhoneNumber)
                .field("amount", amount)
                .asString();

        // Save the transaction details to the database
        Transaction transaction = new Transaction();
        transaction.setClientPhoneNumber(clientPhoneNumber);
        transaction.setNursePhoneNumber(nursePhoneNumber);
        transaction.setAmount(amount);
        transaction.setTransactionStatus(response.getStatusText());
        transaction.setTransactionId(response.getBody());
        transaction.setTimestamp(LocalDateTime.now());

        transactionRepository.save(transaction); // Save to database

        return response.getBody();
    }

    public String checkTransactionStatus(String transactionId) {
        return transactionId;
    }
}
