package com.example.BillingSystem.controller;

import com.example.BillingSystem.service.PaymentService;
import com.example.BillingSystem.service.LocationService;
import com.example.BillingSystem.service.ServiceTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/service-request")
public class ServiceRequestController {

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private LocationService locationService;

    @Autowired
    private ServiceTypeService serviceTypeService;

    // Endpoint to handle the initiation of the service request
    @PostMapping("/initiate")
    public ResponseEntity<Map<String, Object>> initiatePayment(@RequestParam String clientPhoneNumber,
                                                               @RequestParam String nursePhoneNumber,
                                                               @RequestParam String clientLocation,
                                                               @RequestParam String nurseLocation,
                                                               @RequestParam String serviceType,
                                                               @RequestParam String nurseCompetence,
                                                               @RequestParam String serviceTime) {

        // Geocode the locations of the client and nurse
        double[] clientCoordinates = locationService.getCoordinates(clientLocation);
        double[] nurseCoordinates = locationService.getCoordinates(nurseLocation);

        if (clientCoordinates == null || nurseCoordinates == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid location input"));
        }

        // Calculate the distance between client and nurse
        double distance = locationService.calculateDistance(clientCoordinates[0], clientCoordinates[1], nurseCoordinates[0], nurseCoordinates[1]);

        // Get the service type and calculate the base price
        double servicePrice = serviceTypeService.calculatePrice(serviceType, nurseCompetence, distance, serviceTime);

        // Create the payment request
        String paymentResponse = paymentService.initiatePayment(clientPhoneNumber, nursePhoneNumber, String.valueOf(servicePrice));

        // Return the response
        Map<String, Object> response = new HashMap<>();
        response.put("paymentResponse", paymentResponse);
        response.put("calculatedPrice", servicePrice);
        return ResponseEntity.ok(response);
    }

    // Endpoint to check the transaction status
    @GetMapping("/transaction-status/{transactionId}")
    public ResponseEntity<String> checkTransactionStatus(@PathVariable String transactionId) {
        String status = paymentService.checkTransactionStatus(transactionId);
        return ResponseEntity.ok(status);
    }

    // Endpoint to handle location input and get the coordinates
    @PostMapping("/geocode")
    public Object geocodeLocation(@RequestParam String location) {
        double[] coordinates = locationService.getCoordinates(location);
        if (coordinates == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Unable to geocode the location"));
        }

        Map<String, Double> result = new HashMap<>();
        result.put("latitude", coordinates[0]);
        result.put("longitude", coordinates[1]);

        return ResponseEntity.ok(result);
    }

    // Endpoint to upload service type information
    @PostMapping("/upload-service-type")
    public ResponseEntity<String> uploadServiceType(@RequestParam MultipartFile file) {
        // Logic to handle the uploaded service type file
        // The file can contain a list of services and pricing info

        try {
            // Call the service method to process the uploaded file
            serviceTypeService.processServiceTypeFile(file);
            return ResponseEntity.ok("Service type file processed successfully");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error processing file: " + e.getMessage());
        }
    }
}
