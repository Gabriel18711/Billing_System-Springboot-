package com.example.BillingSystem.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AmmountClass {
    private double amount;
}
