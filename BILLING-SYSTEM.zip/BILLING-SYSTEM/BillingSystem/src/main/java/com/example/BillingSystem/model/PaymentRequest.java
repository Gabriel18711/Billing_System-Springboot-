package com.example.BillingSystem.model;

public class PaymentRequest {

    private String clientPhoneNumber;
    private String nursePhoneNumber;
    private String amount;

    // Getters and Setters
    public String getClientPhoneNumber() {
        return clientPhoneNumber;
    }

    public void setClientPhoneNumber(String clientPhoneNumber) {
        this.clientPhoneNumber = clientPhoneNumber;
    }

    public String getNursePhoneNumber() {
        return nursePhoneNumber;
    }

    public void setNursePhoneNumber(String nursePhoneNumber) {
        this.nursePhoneNumber = nursePhoneNumber;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
